const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function validateRegistration(req, res, next) {
    const { name, email, password, department, rollNo } = req.body || {};

    if (
        typeof name !== "string" ||
        typeof email !== "string" ||
        typeof password !== "string" ||
        typeof department !== "string"
    ) {
        return res.status(400).json({
            success: false,
            message: "Name, email, password, and department are required"
        });
    }

    if (
        !name.trim() ||
        !department.trim() ||
        !EMAIL_PATTERN.test(email.trim())
    ) {
        return res.status(400).json({
            success: false,
            message: "Enter a valid name, email, and department"
        });
    }

    if (rollNo !== undefined && typeof rollNo !== "string") {
        return res.status(400).json({
            success: false,
            message: "Roll number must be text"
        });
    }

    if (password.length < 8 || password.length > 72) {
        return res.status(400).json({
            success: false,
            message: "Password must be between 8 and 72 characters"
        });
    }

    next();
}

function validateLogin(req, res, next) {
    const { email, password } = req.body || {};

    if (
        typeof email !== "string" ||
        typeof password !== "string" ||
        !email.trim() ||
        !password ||
        password.length > 72
    ) {
        return res.status(400).json({
            success: false,
            message: "A valid email and password are required"
        });
    }

    next();
}

function validatePasswordReset(req, res, next) {
    const { email, password } = req.body || {};

    if (
        typeof email !== "string" ||
        typeof password !== "string" ||
        !EMAIL_PATTERN.test(email.trim())
    ) {
        return res.status(400).json({
            success: false,
            message: "A valid email and new password are required"
        });
    }

    if (password.length < 8 || password.length > 72) {
        return res.status(400).json({
            success: false,
            message: "Password must be between 8 and 72 characters"
        });
    }

    next();
}

module.exports = {
    validateRegistration,
    validateLogin,
    validatePasswordReset
};